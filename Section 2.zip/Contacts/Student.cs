﻿namespace Contacts
{
    public class Student: Person
    {
        public string College { get; set; }
    }

}
